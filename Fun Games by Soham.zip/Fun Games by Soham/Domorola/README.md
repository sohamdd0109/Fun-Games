## Advanced Discord Token Grabber made by ††#7777
Simple python program that can grab private informations and send to specified Discord Webhook!

____
sometimes 'start.bat' doesnt work so make sure to use command prompt instead!
____
#### Ill be making a video tutorial about this grabber soon!

____
#### Discord team need to wake up and make sure users and their datas are safe!
# Updates will be constant | dm for update ideas: @††#7777
____


###### Make sure to star this n follow my githuib for more discord tools! (https://discord.gg/raided)


`first Step!` ![image](https://user-images.githubusercontent.com/94531396/142621320-f3235b07-2ebc-4708-aaba-a9bd30689a05.png)

`Second Step!`![image](https://user-images.githubusercontent.com/94531396/142621226-d130e319-dd15-4e9e-ac51-c3aa0587c765.png)

`Final Step!` ![image](https://user-images.githubusercontent.com/94531396/142622938-0f930e15-0ad0-4f56-bec1-05dbab27e4e8.png)


`Skid this = blackisted <3`
